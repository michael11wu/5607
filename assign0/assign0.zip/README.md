# Assignment 0
Program creates a checkerboard image of white and black.
Takes in input from command line that will define the height and width of image